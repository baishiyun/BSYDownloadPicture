//
//  DownloadImageCell.m
//  downloadImageDemo
//
//  Created by 白仕云 on 2018/5/15.
//  Copyright © 2018年 BSY.com. All rights reserved.
//

#import "DownloadImageCell.h"
#import <Masonry.h>
#import "BSYDownloadPicture.h"

@interface DownloadImageCell()
@property (nonatomic ,strong)UIImageView *icon;
@end
@implementation DownloadImageCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self  =[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {

        [self addSubview:self.icon];
        [self.icon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.equalTo(@(5));
            make.right.bottom.equalTo(@(-5));
        }];

    }
    return self;
}
-(UIImageView *)icon
{
    if (!_icon) {
        _icon = [[UIImageView alloc]init];
    }
    return _icon;
}

-(void)setMode:(FileOptionsURLMode *)mode
{
    _mode = mode;

    if (mode.downloadImage) {
        self.icon.image = mode.downloadImage;
    }else{

        if (mode.url) {
            [[BSYDownloadPicture shareDownloadPicture] bsy_DownloadPictureWithUrl:mode.url succeedCallBack:^(UIImage *image) {
                self.icon.image = image;
                if (self.DownloadImageBlock) {
                    self.DownloadImageBlock(self,image);
                }
            } failCallBack:^{
            }];
        }
    }


}

@end
