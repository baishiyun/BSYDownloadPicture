//
//  DownloadImageManger.h
//  downloadImageDemo
//
//  Created by 白仕云 on 2018/5/15.
//  Copyright © 2018年 BSY.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface DownloadImageManger : NSObject


/**
 下载图片

 @param url 地址
 @param loadingView 试图
 @param callBack 回掉
 */
+(void)downloadWithUrl:(NSString *)url loadingview:(UIView *)loadingView callBack:(void(^)(id response))callBack;
@end
