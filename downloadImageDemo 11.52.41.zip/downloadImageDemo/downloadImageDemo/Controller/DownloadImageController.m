//
//  DownloadImageController.m
//  downloadImageDemo
//
//  Created by 白仕云 on 2018/5/15.
//  Copyright © 2018年 BSY.com. All rights reserved.
//

#import "DownloadImageController.h"
#import "DownloadImageCell.h"
#import "DownloadImageManger.h"
#import "DownloadImageMode.h"
#import <MJExtension/MJExtension.h>
#import <Masonry.h>
#import <MJRefresh/MJRefresh.h>
static NSString *const DownloadImageCellID = @"DownloadImageCell";
@interface DownloadImageController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic ,strong)UITableView *list;
@property (nonatomic ,strong)NSMutableArray *array;
@property (nonatomic ,assign)int pageToken;
@end

@implementation DownloadImageController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self creatUIs];
    [self getData];
    self.pageToken= 1;

    self.list.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(refreshMoreDatas)];
    self.list.mj_header = [MJRefreshHeader headerWithRefreshingTarget:self refreshingAction:@selector(refreshHeader)];
}
-(void)refreshMoreDatas
{
    self.pageToken= 1+self.pageToken;
    [self getData];
    [self.list.mj_footer  endRefreshing];

}

-(void)refreshHeader
{
    self.pageToken= 1;
      [self getData];
    [self.list.mj_header  endRefreshing];

}
-(void)getData{

      @autoreleasepool{
    NSString *url = [NSString stringWithFormat:@"http://120.76.205.241:8000/photo/duitang?kw=landscape&pageToken=%d&apikey=veFwkAxysi564Eqw86usU9W0JvWjEWByfgtenfjMzJnr3mSmhZNfFIWw3RjMHEYa",self.pageToken];
    [DownloadImageManger downloadWithUrl:url loadingview:self.view callBack:^(id response) {
        NSMutableArray *modelArray = [DownloadImageMode mj_objectArrayWithKeyValuesArray:response];
        for (int index=0; index<modelArray.count; index++) {
            DownloadImageMode *mode = [modelArray objectAtIndex:index];
            [self.array addObjectsFromArray:[FileOptionsURLMode mj_objectArrayWithKeyValuesArray:mode.fileOptions]];
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.list reloadData];
        });
    }];
      }
}
- (void)creatUIs {
    [self.view addSubview:self.list];
    [self.list mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.top.equalTo(@(0));
    }];
    [self.list registerClass:[DownloadImageCell class] forCellReuseIdentifier:DownloadImageCellID];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.array.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    __weak typeof(self)selfWeak = self;
    DownloadImageCell *cell = [tableView dequeueReusableCellWithIdentifier:DownloadImageCellID];
    cell.mode = self.array[indexPath.row];
    [cell setDownloadImageBlock:^(DownloadImageCell *cell,UIImage*icom) {
        NSIndexPath *index = [tableView indexPathForCell:cell];
        FileOptionsURLMode *model =selfWeak.array[index.row];
        model.downloadImage = icom;
        [selfWeak.array replaceObjectAtIndex:index.row withObject:model];
    }];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [UIScreen mainScreen].bounds.size.height;
}
-(NSMutableArray *)array
{
    if (!_array) {
        _array = [NSMutableArray array];
    }
    return _array;
}
-(UITableView *)list
{
    if (!_list) {
        _list = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _list.tableFooterView = [[UIView alloc]init];
        _list.dataSource = self;
        _list.delegate = self;
    }
    return _list;
}
@end
