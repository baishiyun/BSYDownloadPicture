//
//  DownloadImageManger.m
//  downloadImageDemo
//
//  Created by 白仕云 on 2018/5/15.
//  Copyright © 2018年 BSY.com. All rights reserved.
//

#import "DownloadImageManger.h"
@interface DownloadImageManger()
@end
@implementation DownloadImageManger

/**
 下载图片

 @param url 地址
 @param loadingView 试图
 @param callBack 回掉
 */
+(void)downloadWithUrl:(NSString *)url loadingview:(UIView *)loadingView callBack:(void(^)(id response))callBack
{

    UIActivityIndicatorView *Activity = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(loadingView.frame.size.width/2.0-30, loadingView.frame.size.height/2.0-30, 60, 50)];
    Activity.activityIndicatorViewStyle = UIActivityIndicatorViewStyleGray;
    [loadingView addSubview:Activity];
    [Activity startAnimating];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
    NSURLSession *sesion = [NSURLSession sharedSession];
    NSURL *urlString = [NSURL URLWithString:[url stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]];
    NSURLSessionDataTask *task= [sesion dataTaskWithURL:urlString completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSMutableArray *resultArray  =[NSMutableArray array];
        if (!error) {
            if (data) {
                id responseData = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
                if ([responseData isKindOfClass:[NSDictionary class]]) {
                    if ([[responseData allKeys] containsObject:@"data"]) {
                        NSArray *dataArray = [responseData objectForKey:@"data"];
                            [resultArray addObjectsFromArray:dataArray];
                    }
                }

            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [Activity stopAnimating];
            if (callBack) {
                callBack(resultArray);
            }
        });
    }];
        [task resume];
    });
}
@end
