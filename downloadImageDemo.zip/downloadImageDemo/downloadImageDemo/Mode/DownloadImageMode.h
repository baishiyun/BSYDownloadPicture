//
//  DownloadImageMode.h
//  downloadImageDemo
//
//  Created by 白仕云 on 2018/5/15.
//  Copyright © 2018年 BSY.com. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface DownloadImageMode : NSObject
@property (nonatomic ,copy)NSString *albumTitle;
@property (nonatomic ,strong)NSMutableArray *fileOptions;
@end
