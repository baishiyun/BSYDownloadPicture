//
//  DownloadImageCell.h
//  downloadImageDemo
//
//  Created by 白仕云 on 2018/5/15.
//  Copyright © 2018年 BSY.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FileOptionsURLMode.h"
@interface DownloadImageCell : UITableViewCell
@property (nonatomic ,strong)FileOptionsURLMode *mode;
@property (nonatomic ,copy)void(^DownloadImageBlock)(DownloadImageCell *cell ,UIImage *icon);
@end
